<?php 

$servername = "localhost";
$dBUsername = "root";
$dbPassword = "";
$dBName = "ems";

$conn = mysqli_connect($servername, $dBUsername, $dbPassword, $dBName);

if(!$conn){
	echo "Databese Connection Failed";
}


if (isset($_POST['username']) ||
	isset($_POST['phonenumber'])||
	isset($_POST['email']) ||
	isset($_POST['pass']))	{

	//include "dbh.php";

	$username = $_POST['username'];
	$phone_number = $_POST['phonenumber'];
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	
	// echo $username; 
	// echo $pass; 
	// echo $email; 
	
	echo $phone_number;
	if (empty($username)) {
		header("Location: signup.php?ms=Name is required");
	    exit;
		
	}
	else if(empty($phone_number)) {
		header("Location: signup.php?ms=Password is required");
	    exit;
	}else if(empty($email)) {
		header("Location: signup.php?ms=Mobile Number is required");
	    exit;
	}else if(empty($pass)) {
		header("Location: signup.php?ms=Email Id  is required");
	    exit;
	}
	else {
		
        $sql = "INSERT INTO sign_up(username,email,phone_number, pass )VALUES('$username','$email','$phone_number','$pass')";
        $result = mysqli_query($conn, $sql);

        if ($result) {
        	$ms = "Successfully created";
        	header("Location: elogin.php?ms=$ms");
	        exit;
        }else {
        	$ms = "Unknown error occurred";
        	header("Location: signup.php?ms=$ms");
	        exit;
        }

	}
}else {
	header("Location: signup.php");
	exit;
}
