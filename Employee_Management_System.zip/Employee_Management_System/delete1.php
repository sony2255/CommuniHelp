<?php 
require_once('dbh.php');
session_start(); // Start a session

if (isset($_GET['ref_id'])) {
	//include "dbh.php";
	$id = $_GET['ref_id'];

	$sql = "DELETE FROM offer_request WHERE ref_id = $id";
	$result = mysqli_query($conn, $sql);
	if ($result) {
		$ms = "successfully deleted";
		header("Location: myhistory1.php?ms=$ms");
	    exit;
	}else {
		$ms = "Unknown error occurred";
		//header("Location: historyoff.php?ms=$ms");
	    exit;
	}
}else {
	header("Location: myhistory1.php");
	exit;
}
?>