<!DOCTYPE html>
<html lang="en">
  <?php
session_start();
?>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Free Contact Form :: W3layouts</title>
  <link rel="stylesheet" href="addoffercss/style.css">
  <style>
    /* Google Font Link */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Ubuntu:wght@400;500;700&display=swap');*{
margin: 0;
padding: 0;
box-sizing: border-box;
text-decoration: none;
font-family: 'Ubuntu', sans-serif;
}
nav{
position: fixed;
top: 0;
left: 0;
width: 100%;
padding: 20px;
transition: all 0.4s ease;
}
nav.sticky{
padding: 15px 20px;
background: #244065;
box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
}
nav .nav-content{
height: 100%;
max-width: 1200px;
margin: auto;
display: flex;
align-items: center;
justify-content: space-between;
}
nav .logo a{
font-weight: 500;
font-size: 35px;
color: #244065;
}
nav.sticky .logo a{
color: #fff;
}
.nav-content .nav-links{
display: flex;
}
.nav-content .nav-links li{
list-style: none;
margin: 0 8px;
}
.nav-links li a{
text-decoration: none;
color: #0E2431;
font-size: 18px;
font-weight: 500;
padding: 10px 4px;
transition: all 0.3s ease;
}
.nav-links li a:hover{
 color: #244065;
}
nav.sticky .nav-links li a{
 color: #fff;
 transition: all 0.4s ease;
}
nav.sticky .nav-links li a:hover{
color: #0E2431;
}
.home{
height: 100vh;
width: 100%;
background: url("images/background.png") no-repeat;
background-size: cover;
background-position: center;
background-attachment: fixed;
font-family: 'Ubuntu', sans-serif;
}
h2{
font-size: 30px;
margin-bottom: 6px;
color: #244065;
}
.text{
text-align: justify;
padding: 40px 80px;
box-shadow: -5px 0 10px rgba(0, 0, 0, 0.1);
}
  </style>
</head>

<body>

  <!-- contact1 -->
  <nav>
    <div class="nav-content">
      <a href="settings.html"><img class="hamburger-icon" src="images/hamburgericon-removebg-preview.png" style="width:30px; height: 30;"></a>
    
      <div class="logo"  >
        <a href="#"style="margin-left:-10px">CommuniHelp</a>
      </div>
      
      &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
      <ul class="nav-links" style="margin-left:300px">
        <li><a href="home.php">Home</a></li>
        <li><a href="myhistory.php">My History</a></li>
        <li><a href="profile.php">Profile</a></li>
        
        
      </ul>
      
      <a href="notify.php"><img class="bell-icon" src="images/891012-removebg-preview.png" style="width:30px; height: 30;"></a>
      <br><br>
    </div>
  </nav>
  <br><br><br>
  <section class="w3l-simple-contact-form1">
    <div class="contact-form section-gap">
      <div class="wrapper">
        <div class="contact-form" style="max-width: 450px; margin: 0 auto;">
          <div class="form-mid">
            <form action="createmedical.php" method="post">
              <div >
                <label>Select Category</label><br><br>
                
                <input type="radio" style="width: 30px; height: 20px; padding: 10px;"  name="category" value="blood" >
                <label>Blood</label><br>
                
                <input type="radio" style="width: 30px; height: 20px; padding: 10px;"  name="category" value="medicine">
                <label>Medicine</label><br>

                <input type="radio" style="width: 30px; height: 20px; padding: 10px;"  name="category" value="others">
                <label>Others</label><br>
              </div><br />
              <textarea name="details" class="form-control" id="w3lMessage" placeholder="Enter details..."
                required=""></textarea>
                <input type="hidden" name="name" value="<?php echo isset($_SESSION["user_id"]) ? $_SESSION["user_id"]:'';?>">
              <button type="submit" class="btn btn-contact">Add offer</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- /contact1 -->


  <script>
    let nav = document.querySelector("nav");
      window.onscroll = function() {
        if(document.documentElement.scrollTop > 20){
          nav.classList.add("sticky");
        }else {
          nav.classList.remove("sticky");
        }
      }
    </script>
</body>

</html>