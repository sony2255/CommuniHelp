<!DOCTYPE html>
<html>
<head>
   <title></title>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   </head>
   <body align ="center">
   <form method='POST'>
   <h2>Please input your User Id:</h2>
 <input type="text" name="uid">
 <br>
 <br><br>
 <input type="submit" value="Submit Name">
 </form>
<?php
//Retrieve name from query string and store to a local variable
$uid;
$uid = $_POST['uid'];

echo "<h3> User Id is: $uid </h3>";

$conn = new mysqli('localhost', 'root', '', 'testing'); 
 
// Check connection 
if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error); 
} 
 
$sql = "SELECT * FROM user where uid = $uid";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "User id: " . $row["uid"]. "<br>";
	echo" User Name: " . $row["uname"]."<br>";
  }
} else {
  echo "0 results";
}
$conn->close();


?>
</body>
</html>
