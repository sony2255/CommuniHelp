-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 30, 2023 at 09:34 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ems`
--

-- --------------------------------------------------------

--
-- Table structure for table `offer_request`
--

CREATE TABLE `offer_request` (
  `ref_id` int(11) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `offerrequest` varchar(10) NOT NULL,
  `type` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `details` varchar(200) NOT NULL,
  `date&time` datetime NOT NULL DEFAULT current_timestamp(),
  `accept_status` tinyint(1) NOT NULL,
  `proceed_status` tinyint(1) NOT NULL,
  `accept_user_id` varchar(10) NOT NULL,
  `yesno` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `offer_request`
--

INSERT INTO `offer_request` (`ref_id`, `user_id`, `offerrequest`, `type`, `category`, `details`, `date&time`, `accept_status`, `proceed_status`, `accept_user_id`, `yesno`) VALUES
(2, '8', 'offer', 'products', 'carpenter', 'SDTH', '2023-08-30 12:05:10', 1, 0, '1', 0),
(5, '8', 'offer', 'products', 'study_materials', 'sw4the', '2023-09-01 23:29:58', 1, 0, '15', 0),
(8, '8', 'offer', 'products', 'Clothes', 'aefv', '2023-09-01 23:46:06', 1, 1, '14', 0),
(11, '8', 'offer', 'services', 'electrician', 'wsgvs', '2023-09-01 23:49:04', 1, 1, '15', 0),
(13, '1', 'offer', 'products', 'carpenter', 'xfm', '2023-09-02 00:16:37', 0, 0, '', 0),
(14, '8', 'offer', 'medical emergency', 'others', 'sznx', '2023-09-02 00:16:44', 1, 0, '15', 0),
(17, '8', 'request', 'medical emergency', 'medicine', 'xdmd,', '2023-09-02 00:17:07', 1, 1, '15', 0),
(18, '14', 'request', 'services', 'carpenter', 'zejs45u', '2023-09-02 00:17:14', 0, 0, '', 0),
(19, '8', 'offer', 'medical emergency', 'medicine', 'sony', '2023-09-02 09:18:20', 0, 1, '', 0),
(20, '1', 'offer', 'medical emergency', 'others', 'wheelchairs', '2023-09-02 09:20:06', 1, 1, '18', 1),
(21, '1', 'offer', 'products', 'food_materials', 'food', '2023-09-02 09:28:33', 0, 1, '', 0),
(22, '1', 'offer', 'products', 'study_materials', 'study', '2023-09-02 09:35:01', 1, 1, '15', 1),
(25, '1', 'request', 'products', 'food_materials', 'food', '2023-09-02 09:36:47', 1, 0, '1', 0),
(28, '14', 'offer', 'medical emergency', 'medicine', 'medicine related to fever', '2023-09-03 19:39:01', 1, 0, '15', 0),
(29, '14', 'request', 'products', 'food_materials', 'i need food materials like rice and bread for orphanage', '2023-09-03 19:40:26', 0, 0, '', 0),
(30, '15', 'offer', 'products', 'Clothes', 'boys 10 years', '2023-09-09 00:10:26', 0, 0, '', 1),
(32, '15', 'request', 'medical emergency', 'medicine', 'dolo', '2023-09-12 09:32:29', 1, 1, '14', 1),
(33, '15', 'request', 'medical emergency', 'blood', 'A -ve', '2023-09-12 09:38:06', 1, 1, '14', 1),
(35, '14', 'request', 'medical emergency', 'medicine', 'A-ve', '2023-09-12 09:49:29', 0, 0, '', 0),
(36, '14', 'request', 'medical emergency', 'medicine', 'para', '2023-09-12 09:49:40', 1, 1, '8', 1),
(38, '1', 'offer', 'medical emergency', 'medicine', 'cipla', '2023-09-12 09:55:34', 1, 1, '16', 1),
(41, '17', 'request', 'products', 'study_materials', 'dbms', '2023-09-12 16:08:46', 1, 0, '1', 1),
(42, '17', 'offer', 'products', 'electrical_appliances', 'laptap', '2023-09-12 16:09:08', 0, 0, '', 0),
(43, '16', 'request', 'products', 'carpenter', 'chair', '2023-09-13 15:21:45', 0, 0, '', 0),
(44, '18', 'offer', 'products', 'food_materials', 'i have raw rice', '2023-09-14 10:34:48', 1, 1, '14', 1),
(45, '1', 'offer', 'products', 'Clothes', 'for girls', '2023-09-26 10:34:23', 0, 0, '', 0),
(46, '18', 'request', 'medical emergency', 'blood', 'Need B-ve blood in miapur\r\ncontact number: 9897654321', '2023-09-27 22:46:19', 1, 1, '21', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sign_up`
--

CREATE TABLE `sign_up` (
  `user_id` int(10) NOT NULL,
  `username` varchar(25) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `pass` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sign_up`
--

INSERT INTO `sign_up` (`user_id`, `username`, `email`, `phone_number`, `pass`) VALUES
(1, 'maina1', 'mainareddy25@outlook.com', '+918897382361', '123'),
(8, 'sony', 'sony@gmail.com', '2222222222', 'ssss'),
(9, 'sony', 'zsrhgsez', '2222222222', 'sxerht'),
(11, 'maina kadiri', 'sourav@gmail.com', '8989898989', '12345'),
(13, 'charan', 'charan@gmail.com', '9573659924', 'qwerty'),
(14, 'bhargava', 'gsbhargava2004@gmail.com', '8317583098', 'bar'),
(15, 'revathi', 'revathi@gmail.com', '9573659924', 'rev'),
(16, 'sourav', 'sourav@gmail.com', '1234567890', 'sou'),
(17, 'Ishika', 'Ishika@gmail.com', '9908152187', 'ish'),
(18, 'lahari', 'lahari@gmail.com', '7765487654', 'lah'),
(19, 'ishika', 'Ishika@gmail.com', '5647382901', 'ish'),
(20, 'ishika', 'Ishika@gmail.com', '5647382901', 'ish'),
(21, 'pranavi', 'pranavi@gmail.com', '4546474849', 'pra');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `offer_request`
--
ALTER TABLE `offer_request`
  ADD PRIMARY KEY (`ref_id`);

--
-- Indexes for table `sign_up`
--
ALTER TABLE `sign_up`
  ADD PRIMARY KEY (`user_id`,`email`,`phone_number`),
  ADD UNIQUE KEY `user_id` (`user_id`,`email`,`phone_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `offer_request`
--
ALTER TABLE `offer_request`
  MODIFY `ref_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `sign_up`
--
ALTER TABLE `sign_up`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
