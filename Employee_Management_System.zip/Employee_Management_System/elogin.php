<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="globals.css" />
    <link rel="stylesheet" href="style.css" />
    <style>
        .desktop {
  background-color: #ffffff;
  display: flex;
  flex-direction: row;
  justify-content: center;
  width: 100%;
}

.desktop .div {
  background-color: #ffffff;
  width: 1440px;
  height: 1024px;
  position: relative;
}

.desktop .rectangle {
  position: absolute;
  width: 316px;
  height: 206px;
  top: 10px;
  left: 557px;
  object-fit: cover;
}

.desktop .overlap {
  width: 267px;
  height: 30px;
  top: 431px;
  left: 575px;
  background-color: #f0f0f0;
  position: absolute;
  border-radius: 10px;
}

.desktop .text-wrapper {
  position: absolute;
  top: 300px;
  left: 575px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #a6a6a6;
  font-size: 12px;
  letter-spacing: 0;
  line-height: normal;
}

.desktop .overlap-group {
  width: 267px;
  height: 30px;
  top: 350px;
  left: 575px;
  background-color: #f0f0f0;
  position: absolute;
  border-radius: 10px;
}

.desktop .text-wrapper-2 {
  position: absolute;
  top: 395px;
  left: 575px;
  font-family: "Inter-ExtraLight", Helvetica;
  font-weight: 200;
  color: #244065;
  font-size: 10px;
  letter-spacing: 0;
  line-height: normal;
  white-space: nowrap;
}

.desktop .div-wrapper {
  width: 195px;
  height: 25px;
  top: 500px;
  left: 615px;
  background-color: #244065;
  position: absolute;
  border-radius: 10px;
}

.desktop .text-wrapper-3 {
  position: absolute;
  width: 91px;
  top: 7px;
  left: 75px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #ffffff;
  font-size: 14px;
  letter-spacing: 0;
  line-height: normal;
}

.desktop .text-wrapper-4 {
  position: absolute;
  top: 225px;
  left: 615px;
  font-family: "Inter-Regular", Helvetica;
  font-weight: 400;
  color: #244065;
  font-size: 30px;
  letter-spacing: 0;
  line-height: normal;
}

    </style>
  </head>
  <body>
    
    <div class="desktop">
      <div class="div">
		
        
      <img class="rectangle" src="images\logo.jpg" />
      <form action="aprocess.php" method="post">
			<input style="width:270px; margin-left: 0%; height:30px;"  name="email"  class="text-wrapper overlap" placeholder=" Email or Phone" type="text">
			<input style="width:270px; margin-left: 0%; height:30px;"  name="pass"  class="text-wrapper overlap-group" placeholder=" password" type="password">
        <div class="text-wrapper-2">For queries contact : mainakadiri25@gmail.com</div>
        
        <input class="div-wrapper" type="submit" style="color: #f0f0f0;" value="login"><div class="text-wrapper-3">LOGIN</div>
        <div class="text-wrapper-4">Welcome Back</div>
      </form>
      </div>
    </div>
  
  </body>
</html>
