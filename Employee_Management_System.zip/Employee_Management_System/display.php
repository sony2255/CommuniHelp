<?php
//Retrieve name from query string and store to a local variable
session_start();
$uid = $_SESSION['user_id'];
echo $uid;
echo "<h3> User Id is: $uid </h3>";

$conn = new mysqli('localhost', 'root', '', 'ems'); 
 
// Check connection 
if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error); 
} 
 else{
	 echo "Connected Database";
$sql = "SELECT * FROM sign_up where user_id = $uid";
//$result = $conn->query($sql);
$result = mysqli_query($conn, $sql);


if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $username = $row["username"];
    $email = $row["email"];

	echo" User Name: " . $username."<br>";
  echo" Email: " . $email."<br>";
 
  }
} else {
  echo "0 results";
 }
 
$conn->close();
 }

?>