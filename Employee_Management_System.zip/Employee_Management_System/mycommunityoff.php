
<?php
require_once('dbh.php');
session_start(); // Start a session

// Define the user ID and type (offer or request)
$userid = $_SESSION['user_id'];
$type = "offer"; // Change this to "request" if needed
$category = "products";
$act="0";
// Query the database based on the user ID and type
$sql = "SELECT * FROM `offer_request` WHERE offerrequest = '$type' and accept_user_id='$userid' and proceed_status='$act'";
$result = mysqli_query($conn, $sql);

$items = array(); // Initialize an array to store the fetched items

// if ($result) {
//     while ($row = mysqli_fetch_assoc($result)) {
//         // Assuming you have columns like 'username' and 'description' in your database
//         $username = $row['user_id'];
//         $refid = $row['ref_id'];
//         $category = $row['category'];
//         $details = $row['details'];


//       echo '<tr>';
      
//       echo '<td>'.$username.'</td>';
//       echo '<td>'.$refid.'</td>';
//         echo '<td>'.$category.'</td>';
//         echo '<td>'.$details.'</td>';
        
//         echo '</tr>';
//     }
// } else {
//     // Handle the database query error
//     echo "Error: " . mysqli_error($conn);
// }

// Convert the fetched data to JSON format for JavaScript use
$items_json = json_encode($items);
?>
 
 
 <!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Home </title>
    <link rel="stylesheet" href="style.css">
    <style>
      /* Google Font Link */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Ubuntu:wght@400;500;700&display=swap');*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  text-decoration: none;
  font-family: 'Ubuntu', sans-serif;
}
nav{
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  padding: 20px;
  transition: all 0.4s ease;
}
nav.sticky{
  padding: 15px 20px;
  background: #244065;
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
}
nav .nav-content{
  height: 100%;
  max-width: 1200px;
  margin: auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
nav .logo a{
  font-weight: 500;
  font-size: 35px;
  color: #244065;
}
nav.sticky .logo a{
  color: #fff;
}
.nav-content .nav-links{
  display: flex;
}
.nav-content .nav-links li{
  list-style: none;
  margin: 0 8px;
}
 .nav-links li a{
  text-decoration: none;
  color: #0E2431;
  font-size: 18px;
  font-weight: 500;
  padding: 10px 4px;
  transition: all 0.3s ease;
}
 .nav-links li a:hover{
   color: #244065;
 }
 nav.sticky .nav-links li a{
   color: #fff;
   transition: all 0.4s ease;
}
 nav.sticky .nav-links li a:hover{
  color: #0E2431;
}
.home{
  height: 100vh;
  width: 100%;
  background: url("images/background.png") no-repeat;
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
  font-family: 'Ubuntu', sans-serif;
}
h2{
  font-size: 30px;
  margin-bottom: 6px;
  color: #244065;
}
.text{
  text-align: justify;
  padding: 40px 80px;
  box-shadow: -5px 0 10px rgba(0, 0, 0, 0.1);
}

.desktop .hamburger-icon {
  width: 8px;
  height: 8px;
  position: absolute;
  top: 13px;
  left: 25px;
}

.desktop .bell-icon {
  width: 8px;
  height: 8px;
  position: absolute;
  top: 15px;
  left: 1335px;
}


.prod{
  margin-left: 70px;
  margin-top: 50px;
  border-radius: 10px;
}
.med{
  margin-left: 350px;
  margin-top: -70px;
  border-radius: 10px;
}
.ser{
  margin-left: 70px;
  margin-top: 40px;
  border-radius: 10px;
}
.myc{
  margin-left: 350px;
  margin-top: -70px;
  border-radius: 10px;
}

    </style>
   </head>
<body>

  <nav>
    <div class="nav-content">
      <a href="settings.html"><img class="hamburger-icon" src="images/hamburgericon-removebg-preview.png" style="width:30px; height: 30;"></a>
    
      <div class="logo"  >
        <a href="#"style="margin-left:-10px">CommuniHelp</a>
      </div>
      
      &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
      <ul class="nav-links" style="margin-left:300px">
        <li><a href="home.php" >Home</a></li>
        <li><a href="myhistory.php">My History</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href=""><?php echo $_SESSION['user_id']; ?></a></li>
		
		
        <a href="notify.php"><img class="bell-icon" src="images/891012-removebg-preview.png" style="width:30px; height: 30;"></a>
      <br><br>
      
      <form action="display.php" method="post">

      </form>
        
      </ul>
      
      

    </div>
    
</div>
  </nav>

  <script>
  let nav = document.querySelector("nav");
    window.onscroll = function() {
      if(document.documentElement.scrollTop > 20){
        nav.classList.add("sticky");
      }else {
        nav.classList.remove("sticky");
      }
    }
  </script>
<?php 
 
?>


</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>CRUD | Check-box and Radio</title>
	<style>
		th {background: #e6e6e6}table, th, td {
      /* border: 2px solid #aaa; 
      border-color : #ededed;*/
			border-collapse: collapse;
			padding: 15px;
      text-align: center;
      background: #fafafa

			/* border: 1px solid #aaa;
			border-collapse: collapse;
			padding: 5px; */
		}

     table, tr {
      border-bottom: 2px solid #aaaaaa;
      border-top: 0px solid #aaaaaa;

      /* border-left: 2px solid #aaaaaa;
      border-right: 2px solid #aaaaaa; */
      border-color : #fafafa;
			border-collapse: collapse;
			
    }

		th {background: #e6e6e6}
		
	body {
	max-width: max-content;
	margin: auto;
	margin-Top : 80px;
	background-color :#ffffff;
	font-size:1.0em;
	}
		label {
        display: inline-block;
        width: 90px;
      }
	  #btn_s{
            width:300px;
			height:35px;
			background-color :#BDEEC5;
			font-size:16px;
			font-face:bold;
			
        }

        #btn_i {
            width:125px;
        }
	</style>
</head>
<body>
	<?php if(mysqli_num_rows($result)){ ?>
		<br />
		
	<table>
		<tr>
			<th>Reference Id</th>
			<th>User ID</th>
			<th>Category</th>
			<th>Details</th>
			<th>Action</th>
      <th>Action</th>
		</tr>
		<?php 
            $i = 0;
            while ($users = mysqli_fetch_assoc($result)) 
			{
            $i++;
		 ?>
		<tr>
		   <td><?=$users['ref_id']?></td>
           <td><?=$users['user_id']?></td>
           <td><?=$users['category']?></td>
		   <td><?=$users['details']?></td>
		   
        
		   <td>
           	   
           	   <a href="proceedoff.php?ref_id=<?=$users['ref_id']?>">Proceed</a>
			</td>
      <td>
           	   
           	   <a href="ignoreoff.php?ref_id=<?=$users['ref_id']?>">Ignore</a>
			</td>
			
           	
		</tr>
	<?php } ?>
	</table><br />
		<div align ="center">
	
	</a>
<?php }else{ ?>
	<h1>Empty!</h1>
	
<?php } ?>
</body>
</html>