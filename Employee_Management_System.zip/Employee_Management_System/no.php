<?php 
require_once('dbh.php');
session_start(); // Start a session
$acc='0';
if (isset($_GET['ref_id'])) {
	//include "dbh.php";
	$id = $_GET['ref_id'];

	// $sql = "DELETE FROM offer_request WHERE ref_id = $id";
    // $sql = "UPDATE offer_request SET proceed_status= $acc WHERE ref_id=$id";
    $sql = "UPDATE offer_request SET accept_status=$acc, proceed_status=$acc, accept_user_id='' WHERE ref_id=$id";
	$result = mysqli_query($conn, $sql);
	if ($result) {
		$ms = "successfully deleted";
		header("Location: notify.php?ms=$ms");
	    exit;
	}else {
		$ms = "Unknown error occurred";
		
	    exit;
	}
}else {
	header("Location: notify.php");
	exit;
}
?>