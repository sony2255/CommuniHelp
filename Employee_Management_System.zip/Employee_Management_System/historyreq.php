<?php
require_once('dbh.php');
session_start(); // Start a session

// Define the user ID and type (offer or request)
$userid = $_SESSION['user_id'];;
$type = "request"; // Change this to "request" if needed

// Query the database based on the user ID and type
$sql = "SELECT * FROM `offer_request` WHERE user_id = '$userid' AND offerrequest = '$type'";
$result = mysqli_query($conn, $sql);

$items = array(); // Initialize an array to store the fetched items

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Assuming you have columns like 'username' and 'description' in your database
        $username = $row['user_id'];
        $refid = $row['ref_id'];
        $category = $row['category'];
        $details = $row['details'];

      echo '<tr>';
      
      echo '<td>'.$username.'</td>';
      echo '<td>'.$refid.'</td>';
        echo '<td>'.$category.'</td>';
        echo '<td>'.$details.'</td>';
        
        echo '</tr>';
    }
} else {
    // Handle the database query error
    echo "Error: " . mysqli_error($conn);
}

// Convert the fetched data to JSON format for JavaScript use
$items_json = json_encode($items);
?>
