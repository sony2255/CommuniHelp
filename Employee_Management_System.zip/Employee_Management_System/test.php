<?php
    $conn=new mysqli("localhost","root","","ems");
    
    $sql = "SELECT user_id from  sign_up where email = '$email'";
    //echo "$sql";

    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) == 1){
        
        $_SESSION['username']= $user_id;
        echo $username;
    }

    else{
        echo ("<SCRIPT LANGUAGE='JavaScript'>
        window.alert('Invalid Email or Password')
        window.location.href='javascript:history.go(-1)';
        </SCRIPT>");
    }
?>

<html>
    <body>
        <form action="test.php" method="post">

            <input type="text" name="email" value="email">
            <input type="submit">

        </form> 
    </body>

</html>