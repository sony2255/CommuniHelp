<?php 
require_once('dbh.php');
session_start(); // Start a session
$acc='1';
$user=$_SESSION['user_id'];
if (isset($_GET['ref_id'])) {
	//include "dbh.php";
	$id = $_GET['ref_id'];

	// $sql = "DELETE FROM offer_request WHERE ref_id = $id";
    $sql = "UPDATE offer_request SET accept_status= $acc, accept_user_id=$user WHERE ref_id=$id";
	$result = mysqli_query($conn, $sql);
	if ($result) {
		$ms = "successfully deleted";
		header("Location: servicesreq.php?ms=$ms");
	    exit;
	}else {
		$ms = "Unknown error occurred";
		
	    exit;
	}
}else {
	header("Location: servicesreq.php");
	exit;
}
?>