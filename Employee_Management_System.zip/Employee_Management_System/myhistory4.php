<!DOCTYPE html>
<html lang="en" >
<head>
  <style>
    /*Generic*/
.wrapper{
  margin: 60px auto;
  text-align: center;
}
h1{
  margin-bottom: 1.25em;
}

/*Specific styling*/
table {
  display: inline-block;
  border: 1px solid #373737;
  margin-bottom: 20px;
  text-align: center;
 }

th {
  font-family: 'Lucida Grande', 'Helvetica Neue', Helvetica, Arial, sans-serif;
  padding: 10px;
  background: #373737;
  color: #fff;
 }

td {
  padding: 10px;
  border: 1px solid #373737;
 }

form {
  background: #f2f2f2;
  padding: 20px;
}
    </style>
  <meta charset="UTF-8">
  <title>CodePen - jQuery Datatable</title>
  <link rel='stylesheet' href='//netdna.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css'><link rel="stylesheet" href="./style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="wrapper">
  <div class="container">

    <div class="row">
      <div class="col-sm-12">
        <h1>My History > Offers</h1>
        
        <div class="paging"></div>
        <table id="example-table">
          <thead>
            <tr>
              <th>User ID</th>
              <th>Reference ID</th>
              <th>Category</th>
              <th>Details</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          
          
            
            <?php include 'historyoff.php'; ?>
            
            
          </tbody>
        </table>
        <div ><a href="selectoffertype.html" ><input type="submit" value="Add Offer" style="width: 70px; height: 20px;"></a>
    </div>
        <div class="paging"></div>
      </div>
    </div>
  </div>
</div>
<!-- partial -->
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
<script src='//netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js'></script>
<script src='https://cdn.rawgit.com/Holt59/datatable/master/js/datatable.jquery.js'></script>
<script src='https://cdn.rawgit.com/Holt59/datatable/master/js/datatable.js'></script><script  src="./script.js"></script>

</body>
</html>
