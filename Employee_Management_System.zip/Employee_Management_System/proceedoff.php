<?php 
require_once('dbh.php');
session_start(); // Start a session
$acc='1';
if (isset($_GET['ref_id'])) {
	//include "dbh.php";
	$id = $_GET['ref_id'];

	// $sql = "DELETE FROM offer_request WHERE ref_id = $id";
    $sql = "UPDATE offer_request SET proceed_status= $acc WHERE ref_id=$id";
	$result = mysqli_query($conn, $sql);
	if ($result) {
		$ms = "successfully proceeded";
		header("Location: mycommunityoff.php?ms=$ms");
	    exit;
	}else {
		$ms = "Unknown error occurred";
		
	    exit;
	}
}else {
	header("Location: mycommunityoff.php");
	exit;
}
?>