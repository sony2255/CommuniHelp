<?php
session_start();
?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Home </title>
    <link rel="stylesheet" href="style.css">
    <style>
      /* Google Font Link */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&family=Ubuntu:wght@400;500;700&display=swap');*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  text-decoration: none;
  font-family: 'Ubuntu', sans-serif;
}
nav{
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  padding: 20px;
  transition: all 0.4s ease;
}
nav.sticky{
  padding: 15px 20px;
  background: #244065;
  box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
}
nav .nav-content{
  height: 100%;
  max-width: 1200px;
  margin: auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
nav .logo a{
  font-weight: 500;
  font-size: 35px;
  color: #244065;
}
nav.sticky .logo a{
  color: #fff;
}
.nav-content .nav-links{
  display: flex;
}
.nav-content .nav-links li{
  list-style: none;
  margin: 0 8px;
}
 .nav-links li a{
  text-decoration: none;
  color: #0E2431;
  font-size: 18px;
  font-weight: 500;
  padding: 10px 4px;
  transition: all 0.3s ease;
}
 .nav-links li a:hover{
   color: #244065;
 }
 nav.sticky .nav-links li a{
   color: #fff;
   transition: all 0.4s ease;
}
 nav.sticky .nav-links li a:hover{
  color: #0E2431;
}
.home{
  height: 100vh;
  width: 100%;
  background: url("images/background.png") no-repeat;
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
  font-family: 'Ubuntu', sans-serif;
}
h2{
  font-size: 30px;
  margin-bottom: 6px;
  color: #244065;
}
.text{
  text-align: justify;
  padding: 40px 80px;
  box-shadow: -5px 0 10px rgba(0, 0, 0, 0.1);
}

.desktop .hamburger-icon {
  width: 8px;
  height: 8px;
  position: absolute;
  top: 13px;
  left: 25px;
}

.desktop .bell-icon {
  width: 8px;
  height: 8px;
  position: absolute;
  top: 15px;
  left: 1335px;
}


.prod{
  margin-left: 70px;
  margin-top: 50px;
  border-radius: 10px;
}
.med{
  margin-left: 350px;
  margin-top: -70px;
  border-radius: 10px;
}
.ser{
  margin-left: 70px;
  margin-top: 40px;
  border-radius: 10px;
}
.myc{
  margin-left: 350px;
  margin-top: -70px;
  border-radius: 10px;
}

    </style>
   </head>
<body>

  <nav>
    <div class="nav-content">
      <a href="settings.html"><img class="hamburger-icon" src="images/hamburgericon-removebg-preview.png" style="width:30px; height: 30;"></a>
    
      <div class="logo"  >
        <a href="#"style="margin-left:-10px">CommuniHelp</a>
      </div>
      
      &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
      <ul class="nav-links" style="margin-left:300px">
        <li><a href="home.php" >Home</a></li>
        <li><a href="myhistory.php">My History</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href=""><?php echo $_SESSION['user_id']; ?></a></li>

        
        
      </ul>
      
      <a href="notify.php"><img class="bell-icon" src="images/891012-removebg-preview.png" style="width:30px; height: 30;"></a>
      <br><br>
    </div>
    <div class="prod"><a href="products.php" ><input type="submit" value="Products" style="width: 400px; height: 125px;" class="prod"></a>
    </div>
    <div class="med"><a href="medical.php" ><input type="submit" value="Medical Emergency" style="width: 400px; height: 125px;" class="med"></a>
    </div>
    <div class="ser"><a href="services.php" ><input type="submit" value="Services" style="width: 400px; height: 125px;" class="ser"></a>
    </div>
    <div class="myc"><a href="mycommunity.php" ><input type="submit" value="My Community" style="width: 400px; height: 125px;" class="myc"></a>
    </div>
    
  </nav>

  
  

  <script>
  let nav = document.querySelector("nav");
    window.onscroll = function() {
      if(document.documentElement.scrollTop > 20){
        nav.classList.add("sticky");
      }else {
        nav.classList.remove("sticky");
      }
    }
  </script>

</body>
</html>