<?php
$local = "localhost";
$user = "root";
$pass = "";
$database = "ems";
$conn = mysqli_connect($local, $user, $pass, $database);

$email = $_post['email'];



//echo $email;
$sql = "SELECT user_id from  sign_up where email = '$email'";
        //echo "$sql";

$result = mysqli_query($conn, $sql);
echo $sql;
if(mysqli_num_rows($result) == 1){
	
	$_SESSION['username']= $user_id;
    echo $username;
}

else{
	echo ("<SCRIPT LANGUAGE='JavaScript'>
    window.alert('Invalid Email or Password')
    window.location.href='javascript:history.go(-1)';
    </SCRIPT>");
}

?>
<html>
<body>

<form action="getuserid.php" method="post">

    <input type="text" name="email" placeholder="email">
    <input type="submit">

</form>

</body>
</html>