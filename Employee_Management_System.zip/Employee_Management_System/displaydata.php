
<html>
    <body>

        <form action="" method ="POST"></form>
        <input type="text" name="nuserid">
        <input type="submit" value="submit">
    </form>
<?php 
 if(!isset($_POST['nuserid'])){
    
// Connect to the database 

$conn = new mysqli('localhost', 'root', '', 'ems'); 
 
// Check connection 
if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error); 
} 
 
//$userid = $_POST['nuserid'];
$userid;
$userid = $_POST['nuserid'];
$sql = "SELECT username FROM sign_up WHERE user_id  = $userid"; 
 
// Execute the query and get the result 
$result = $conn->query($sql); 
 
// Check if the result contains any rows 
if ($result->num_row > 0) { 
    // Get the row as an associative array 
    $rows = $result->fetch_assoc(); 
 
    // Print the username 
    echo $rows['username']; 
}else { 
    echo "No results found"; 
} 

// Close the connection 
$conn->close(); 
}
?>
    </body>
</html>
