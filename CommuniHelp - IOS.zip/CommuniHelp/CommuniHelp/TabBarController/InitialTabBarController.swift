//
//  InitialTabBarController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 09/09/23.
//

import UIKit

class InitialTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        UITabBar.appearance().tintColor = .gray
        
        let items = tabBar.items
        
        items?[0].image = .init(systemName: "house")
        items?[0].title = ""
        
        items?[1].image = .init(systemName: "clock.arrow.circlepath")
        items?[1].title = ""
        
        items?[2].image = .init(systemName: "person.crop.circle")
        items?[2].title = ""
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
