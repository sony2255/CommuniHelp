//
//  ReviewViewController.swift
//  CommuniHelp
//
//  Created by SAIL on 16/11/23.
//

import UIKit

class ReviewViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var reviewTextView: UITextView!
    @IBOutlet weak var addReviewButton: UIButton!
    
    var userId = UserDefaultsManager.shared.getUserId() ?? ""
    var refId = UserDefaultsManager.shared.getUserRefId() ?? ""
    var category = UserDefaultsManager.shared.getCategory() ?? ""
    var details = UserDefaultsManager.shared.getDetails() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
    }
    
    @IBAction func backActionButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func addReview(_ sender: Any) {
        addreview()
    }
    func addreview()
    {
        let formData: [String: String] = [
            "user_id": self.userId,
            "ref_id": self.refId,
            "category": self.category,
            "details": self.details,
                "review": reviewTextView.text ?? ""
            ]
        
        APIHandler().postAPIValues(type: addReviewModel.self, apiUrl:"\(ServiceAPI.addReview)", method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        AlertManager.showAutoDismissAlert(title: "Review", message: "Added SuccessFully", viewController: self, navigationController: self.navigationController!, duration: 2.0)
//                        self.navigationController?.popViewController(animated: true)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }

}
