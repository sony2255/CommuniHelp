//
//  OfferCategoryViewController.swift
//  CommuniHelp
//
//  Created by SAIL on 18/10/23.
//

import UIKit

class OfferCategoryViewController: UIViewController {
    
    @IBOutlet weak var productButton: UIButton!
    @IBOutlet weak var medicalButton: UIButton!
    @IBOutlet weak var serviceButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        shadow.applyShadowButton(to: productButton)
        shadow.applyShadowButton(to: medicalButton)
        shadow.applyShadowButton(to: serviceButton)
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func productButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "AddProductOfferViewController") as! AddProductOfferViewController
        navigationController?.pushViewController(storyboard, animated: true)
    }
    @IBAction func medicalButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "AddMedicalOfferViewController") as! AddMedicalOfferViewController
        navigationController?.pushViewController(storyboard, animated: true)
    }
    @IBAction func ServiceButtonAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "AddServiceOfferViewController") as! AddServiceOfferViewController
        navigationController?.pushViewController(storyboard, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
