//
//  AddServiceOfferViewController.swift
//  CommuniHelp
//
//  Created by SAIL on 18/10/23.
//

import UIKit

class AddServiceOfferViewController: UIViewController {

    @IBOutlet weak var topView: UIButton!
    @IBOutlet weak var plumbingButton: UIButton!
    @IBOutlet weak var electricialButton: UIButton!
    @IBOutlet weak var carpenterButton: UIButton!
    @IBOutlet weak var housekeepingButton: UIButton!
    @IBOutlet weak var othersButton: UIButton!
    @IBOutlet weak var descriptionTextView: UITextView!
    
    var offersList = [String]()
    var request: AddServiceOff!
    let userId : String = UserDefaultsManager.shared.getUserId() ?? ""
    var sender = UIButton().tag
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        self.descriptionTextView.layer.shadowColor = UIColor.black.cgColor
        self.descriptionTextView.layer.shadowOpacity = 0.3
        self.descriptionTextView.layer.shadowOffset = CGSize.zero
        self.descriptionTextView.layer.shadowRadius = 6
        self.descriptionTextView.layer.masksToBounds = true
            
        shadow.vc6 = self
        shadow.radioButton(to: plumbingButton)
        shadow.radioButton(to: electricialButton)
        shadow.radioButton(to: carpenterButton)
        shadow.radioButton(to: housekeepingButton)
        shadow.radioButton(to: othersButton)
        
    }
    
    @IBAction func backActionButton(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func offerButtonAction(_ sender: Any) {
        offerAPI()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func offerAPI() {
        var formData: [String: String] = [
            "user_id": self.userId,
                "details": descriptionTextView.text ?? ""
            ]
        
//        if sender == 1 {
//            formData["category"] = "Clothes"
//        } else if sender == 2 {
//            formData["category"] = "Food Materials"
//        } else if sender == 3 {
//            formData["category"] = "Carpenter"
//        } else if sender == 4 {
//            formData["category"] = "Study Materials"
//        } else if sender == 5 {
//            formData["category"] = "Electrical Appliances"
//        } else if sender == 6 {
//            formData["category"] = "Others"
//        }
//
        switch sender {
        case 0:
            formData["category"] = "Plumbing"
        case 1:
            formData["category"] = "Electrician"
        case 2:
            formData["category"] = "Carpenter"
        case 3:
            formData["category"] = "House Keeping"
        case 4:
            formData["category"] = "Others"
        default:
            formData["category"] = ""
        }
        print(sender)
        
        APIHandler().postAPIValues(type: AddServiceOff.self, apiUrl:"\(ServiceAPI.addServiceOffer)", method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        AlertManager.showAutoDismissAlert(title: "Servicces Offer", message: "Added SuccessFully", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }

}
