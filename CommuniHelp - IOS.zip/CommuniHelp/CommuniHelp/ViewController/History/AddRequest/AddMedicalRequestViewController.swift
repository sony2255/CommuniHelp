//
//  AddMedicalRequestViewController.swift
//  CommuniHelp
//
//  Created by SAIL on 18/10/23.
//

import UIKit


class AddMedicalRequestViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var bloodButton: UIButton!
    @IBOutlet weak var MedicineButton: UIButton!
    @IBOutlet weak var OthersButton: UIButton!
    @IBOutlet weak var descriptionTextView: UITextView!
    
    var offersList = [String]()
    var request: AddMedicalReq!
    let userId : String = UserDefaultsManager.shared.getUserId() ?? ""
    var sender = UIButton().tag
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        self.descriptionTextView.layer.shadowColor = UIColor.black.cgColor
        self.descriptionTextView.layer.shadowOpacity = 0.3
        self.descriptionTextView.layer.shadowOffset = CGSize.zero
        self.descriptionTextView.layer.shadowRadius = 6
        self.descriptionTextView.layer.masksToBounds = true
        
        shadow.vc2 = self
        shadow.radioButton(to: bloodButton)
        shadow.radioButton(to: MedicineButton)
        shadow.radioButton(to: OthersButton)
        
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func requestAction(_ sender: Any) {
        requestAPI()
    }
    
    func requestAPI() {
        var formData: [String: String] = [
            "user_id": self.userId,
                "details": descriptionTextView.text ?? ""
            ]
        
//        if sender == 1 {
//            formData["category"] = "Clothes"
//        } else if sender == 2 {
//            formData["category"] = "Food Materials"
//        } else if sender == 3 {
//            formData["category"] = "Carpenter"
//        } else if sender == 4 {
//            formData["category"] = "Study Materials"
//        } else if sender == 5 {
//            formData["category"] = "Electrical Appliances"
//        } else if sender == 6 {
//            formData["category"] = "Others"
//        }
//
        switch sender {
        case 0:
            formData["category"] = "Blood"
        case 1:
            formData["category"] = "Medicine"
        case 2:
            formData["category"] = "Others"
        default:
            formData["category"] = ""
        }
        print(sender)
        
        APIHandler().postAPIValues(type: AddMedicalReq.self, apiUrl:"\(ServiceAPI.addMedicalRequest)", method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        AlertManager.showAutoDismissAlert(title: "Medical Emergency Request", message: "Added SuccessFully", viewController: self, navigationController: self.navigationController!, duration: 2.0)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                }
            }
        }
}
