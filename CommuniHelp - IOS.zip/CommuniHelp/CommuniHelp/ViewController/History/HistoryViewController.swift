//
//  HistoryViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 09/09/23.
//

import UIKit

class HistoryViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var historyTableView: UITableView!
    @IBOutlet weak var OfferButton: UIButton!
    
    var offers: HistoryOfferModel!
    var requests: HistoryRequestModel!
    var nSelectedSegmentIndex : Int = 1
    
    let userid = UserDefaultsManager.shared.getUserId() ?? ""
    let refid = UserDefaultsManager.shared.getUserRefId() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.historyTableView.delegate = self
        self.historyTableView.dataSource = self
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        //self.historyTableView.delegate = self
       // self.historyTableView.dataSource = self
        
        self.OfferButton.titleLabel?.font = .systemFont(ofSize: 20)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        GetOfferHistory()
        GetRequestHistory()

    }
    
    
    @IBAction func segmentAc(_ sender: Any) {
        
        if (sender as AnyObject).selectedSegmentIndex == 0 {
                self.nSelectedSegmentIndex = 1
            }
            else {
                self.nSelectedSegmentIndex = 2
            }
            self.historyTableView.reloadData()
        
//        if segmentControl.selectedSegmentIndex == 0 {
//           print("First Segment Select")
//            self.OfferButton.setTitle("Offer", for: .normal)
//        }
//        else if segmentControl.selectedSegmentIndex == 1 {
//           print("Second Segment Select")
//            self.OfferButton.setTitle("Request", for: .normal)

        }
        
 
    
    
    @IBAction func offerButtonAction(_ sender: Any) {
        if segmentControl.selectedSegmentIndex == 0 {
            let vc = storyboard?.instantiateViewController(identifier: "OfferCategoryViewController") as! OfferCategoryViewController
            navigationController?.pushViewController(vc, animated: true)
        } else {
            let vc = storyboard?.instantiateViewController(identifier: "RequestCategoryViewController") as! RequestCategoryViewController
            navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    
    func GetOfferHistory() {
        APIHandler().getAPIValues(type: HistoryOfferModel.self, apiUrl: "\(ServiceAPI.myHistoryOffers)user_id=\(userid)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.offers = data
                print(self.offers.data ?? "")
                print(self.offers.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.historyTableView.reloadData()
                }
            case.failure(let error):
                print(error)
            }
        }
    }
    
    func GetRequestHistory() {
        APIHandler().getAPIValues(type: HistoryRequestModel.self, apiUrl: "\(ServiceAPI.myHistoryRequests)user_id=\(userid)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.requests = data
                print(self.requests.data ?? "")
                print(self.requests.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.historyTableView.reloadData()
                }
            case.failure(let error):
                print(error)
            }
        }
    }
    
}

extension HistoryViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if nSelectedSegmentIndex == 1 {
            return self.offers?.data?.count ?? 1
        }
        else {
            return self.requests?.data?.count ?? 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HistoryTableViewCell", for: indexPath) as! HistoryTableViewCell
        
        cell.cellView.layer.cornerRadius = 10
        shadow.applyShadowView(to: cell.cellView)
        
        cell.deleteButton.tag = indexPath.row
        cell.deleteButton.addTarget(self, action: #selector(deleteOfferAPI), for: .touchUpInside)
        
        
        if nSelectedSegmentIndex == 1 {
            if let offer = self.offers?.data?[indexPath.row] {
                cell.infoLabel.text = "\(offer.userID ?? "") : \(offer.category ?? "")\n\(offer.details ?? "")"
            } else {
                cell.infoLabel.text = "No Data"
            }
        } else {
            if let request = self.requests?.data?[indexPath.row] {
                cell.infoLabel.text = "\(request.userID ?? "") : \(request.category ?? "")\n\(request.details ?? "")"
            } else {
                cell.infoLabel.text = "No Data"
            }
        }
        
        cell.deleteButton.titleLabel?.font = .systemFont(ofSize: 12)
        
        return cell
    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return historyData.data?.count ?? 0
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "HistoryTableViewCell") as! HistoryTableViewCell
//        if let hisData =  historyData.data {
//            print(hisData)
//            cell.infoLabel.text = "\(hisData[indexPath.row].refID ?? "") /n \(hisData[indexPath.row].userID ?? "")/n \(hisData[indexPath.row].category ?? "")/n \(hisData[indexPath.row].details ?? "")"
//
//        }
//
//        return cell
    }
    
    @objc func deleteOfferAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        var refID: String? // Initialize refID as an optional String
            
            if self.nSelectedSegmentIndex == 1 {
                // Check if there's an offerRefID at the specified rowToRemove
                if let offerRefID = self.offers?.data?[rowToRemove].refID {
                    refID = offerRefID
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Check if there's a requestRefID at the specified rowToRemove
                if let requestRefID = self.requests?.data?[rowToRemove].refID {
                    refID = requestRefID
                }
            }
            
            guard let validRefID = refID else {
                // Ensure that a valid refID exists for the selected segment
                return
            }
            
            if self.nSelectedSegmentIndex == 1 {
                // Use the selected refID to find the index to remove from "offers" data
                if let indexToRemove = self.offers?.data?.firstIndex(where: { $0.refID == validRefID }) {
                    self.offers?.data?.remove(at: indexToRemove)
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Use the selected refID to find the index to remove from "requests" data
                if let indexToRemove = self.requests?.data?.firstIndex(where: { $0.refID == validRefID }) {
                    self.requests?.data?.remove(at: indexToRemove)
                }
            }
            
            self.historyTableView.reloadData()
            
        let formData: [String: String] = [ "id": validRefID]
        
        APIHandler().postAPIValues(type: deleteModel.self, apiUrl: ServiceAPI.deleteAPI, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    self.GetOfferHistory()
                    self.GetRequestHistory()
                    
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}
