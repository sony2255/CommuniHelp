//
//  SignUpViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 08/09/23.
//

import UIKit

class SignUpViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var TopView: UIView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var phoneNoTextField: UITextField!
    @IBOutlet weak var eMailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPwTextField: UITextField!
    @IBOutlet weak var signUpButton: UIButton!
    
    var login: EmailModel!
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.TopView.layer.cornerRadius = 35
        self.TopView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]

        self.nameTextField.layer.cornerRadius = 10
        addLeftViewToTextField(nameTextField)
        configureTextField(nameTextField, placeholderText: "FULL NAME")
        
        self.phoneNoTextField.layer.cornerRadius = 10
        addLeftViewToTextField(phoneNoTextField)
        configureTextField(phoneNoTextField, placeholderText: "PHONE NO")
        
        self.eMailTextField.layer.cornerRadius = 10
        addLeftViewToTextField(eMailTextField)
        configureTextField(eMailTextField, placeholderText: "E MAIL")
        
        self.passwordTextField.layer.cornerRadius = 10
        addLeftViewToTextField(passwordTextField)
        configureTextField(passwordTextField, placeholderText: "PASSWORD")
        passwordTextField.isSecureTextEntry = true
        
        self.confirmPwTextField.layer.cornerRadius = 10
        addLeftViewToTextField(confirmPwTextField)
        configureTextField(confirmPwTextField, placeholderText: "CONFIRM PASSWORD")
        confirmPwTextField.isSecureTextEntry = true
        
        self.signUpButton.titleLabel?.font = .systemFont(ofSize: 20)
        
    }
    
    func isValidEmailAddress(emailAddressString: String) -> Bool {
            
            var returnValue = true
            let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
            
            do {
                let regex = try NSRegularExpression(pattern: emailRegEx)
                let nsString = emailAddressString as NSString
                let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
                
                if results.count == 0
                {
                    returnValue = false
                }
                
            } catch let error as NSError {
                print("invalid regex: \(error.localizedDescription)")
                returnValue = false
            }
            
            return  returnValue
        }
    
    //TextField_Padding
    func addLeftViewToTextField(_ textField: UITextField) {
        let leftView = UIView(frame: CGRect(x: 5, y: 5, width: 15, height: textField.frame.height))
        textField.leftView = leftView
        textField.leftViewMode = .always
    }
    
    //Placeholder_Text_Colour
    func configureTextField(_ textField: UITextField, placeholderText: String) {
        textField.delegate = self
        textField.attributedPlaceholder = NSAttributedString(
            string: placeholderText,
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.black]
        )
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func signUpButtonAction(_ sender: Any) {
        if nameTextField.text?.isEmpty == true || phoneNoTextField.text?.isEmpty == true || eMailTextField.text?.isEmpty == true || passwordTextField.text?.isEmpty == true || confirmPwTextField.text?.isEmpty == true {
            AlertManager.showAlert(title: "Field is Empty", message: "Please enter all the value", viewController: self)
        } else if isValidEmailAddress(emailAddressString: eMailTextField.text ?? "") != true {
            AlertManager.showAlert(title: "Invalid Email", message: "Please enter the valid Email", viewController: self)
        } else if passwordTextField.text != confirmPwTextField.text {
            AlertManager.showAlert(title: "Incorrect", message: "Password is not equal to confirm password", viewController: self)
        } else {
            getEmailAPI()
//            RegistrationAPI()
        }
        
    }
    
    
    
    func RegistrationAPI() {
            let formData: [String: String] = [
                
                "username": nameTextField.text ?? "",
                "email": eMailTextField.text ?? "",
                "phone_number": phoneNoTextField.text ?? "",
                "pass": passwordTextField.text ?? "",
                
                //"Address": AddressTextField.text ?? "",
                //"blood_group": bloodgroupTextField.text ?? ""
                
            ]
        APIHandler().postAPIValues(type: signupModel.self, apiUrl: "\(ServiceAPI.signUp)", method: "POST", formData: formData) { result in
                switch result {
                case .success(let response):
                    print("Status: \(response.status)")
                    print("Message: \(response.message)")
                    DispatchQueue.main.async {
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let vc = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
                        self.navigationController?.pushViewController(vc, animated: true)
                       //print(formData)
                    }
                case .failure(let error):
                    print("Error: \(error)")
                    let storyboard = UIStoryboard(name: "HomeStoryboard", bundle: nil)
                    let vc = storyboard.instantiateViewController(withIdentifier: "InitialTabBarController") as! InitialTabBarController
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
        }
    
    func getEmailAPI(){
        
        APIHandler().getAPIValues(type: EmailModel.self, apiUrl: ServiceAPI.emailUrl, method: "GET") { result in
            switch result {
            case .success(let data):
                print(data)
                self.login = data
                DispatchQueue.main.async {
                    DispatchQueue.main.async {
                        let enteredEmail = self.eMailTextField.text ?? ""
                        
                        if self.login?.data?.contains(where: { $0.email == enteredEmail }) == true {
                            AlertManager.showAlert(title: "Already Exist", message: "The entered Email is already exist. Please try another Email", viewController: self)
                        } else {
                            self.RegistrationAPI()
                        }
                    }
                }
            case .failure(let error):
                print(error)
                DispatchQueue.main.async {
                    //                    let alert = UIAlertController(title: "Warning", message: "Incorrect ID or Password", preferredStyle: .alert)
                    //                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    //                    self.present(alert, animated: true)
                }
                
            }
        }
    }
}
