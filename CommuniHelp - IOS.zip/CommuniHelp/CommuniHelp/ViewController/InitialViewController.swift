//
//  ViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 08/09/23.
//

import UIKit

class InitialViewController: UIViewController {
    
    @IBOutlet weak var logoImage: UIImageView!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.signUpButton.layer.cornerRadius = 10
        self.signUpButton.titleLabel?.font = .systemFont(ofSize: 20)
        
        self.loginButton.layer.cornerRadius = 10
        self.loginButton.titleLabel?.font = .systemFont(ofSize: 20)
        
    }

    @IBAction func signUpButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "SignUpViewController") as! SignUpViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func loginButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "LoginViewController") as! LoginViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
}

