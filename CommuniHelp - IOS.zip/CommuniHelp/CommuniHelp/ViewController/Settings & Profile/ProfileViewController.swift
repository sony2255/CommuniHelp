//
//  ProfileViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 09/09/23.
//

import UIKit

class ProfileViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var eMailLabel: UILabel!
    @IBOutlet weak var phoneNoLabel: UILabel!
    
    var pass : profileModel!
    
    let userid = UserDefaultsManager.shared.getUserId() ?? ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        shadow.applyShadowLabel(to: nameLabel)
        shadow.applyShadowLabel(to: eMailLabel)
        shadow.applyShadowLabel(to: phoneNoLabel)
    }
    
    override func viewWillAppear(_ animated: Bool) {
            getProfileAPI()
        }
    
    func getProfileAPI() {
//        APIHandler().getAPIValues(type: profileModel.self, apiUrl: ServiceAPI.profile, method: "GET")
        APIHandler().getAPIValues(type: profileModel.self, apiUrl: "\(ServiceAPI.profile)user_id=\(userid)", method: "GET") { result in
                switch result {
                case .success(let data):
                    self.pass = data
                    print(self.pass.data ?? "")
                    DispatchQueue.main.async {
                        self.nameLabel.text = self.pass.data?.username
                        self.eMailLabel.text = self.pass.data?.email
                        self.phoneNoLabel.text = self.pass.data?.phoneNumber
                    }
                case .failure(let error):
                    print(error)
                    DispatchQueue.main.async{
                     
                    }
                }
            }
        }
    
}
