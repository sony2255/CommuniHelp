//
//  SettingViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 10/09/23.
//

import UIKit

class SettingViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var accountButton: UIButton!
    @IBOutlet weak var notificationView: UIView!
    @IBOutlet weak var helpButton: UIButton!
    @IBOutlet weak var aboutButton: UIButton!
    @IBOutlet weak var exitButton: UIButton!
    @IBOutlet weak var helpView: UIView!
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        shadow.applyShadowButton(to: accountButton)
        shadow.applyShadowView(to: notificationView)
        shadow.applyShadowButton(to: helpButton)
        shadow.applyShadowButton(to: aboutButton)
        shadow.applyShadowView(to: helpView)
        
        helpView.isHidden = true
        
        let tap = UITapGestureRecognizer()
        tap.addTarget(self, action: #selector(tapAction))
        view.addGestureRecognizer(tap)
        
        self.exitButton.titleLabel?.font = .boldSystemFont(ofSize: 20)
    }
    
    @objc func tapAction() {
        helpView.isHidden = true
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func accountButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "AccountViewController") as! AccountViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func helpButtonAction(_ sender: Any) {
        helpView.isHidden = false
    }
    
    @IBAction func aboutButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "AboutViewController") as! AboutViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func exitButtonAction(_ sender: Any) {
        AlertManager.showCustomAlert(title: "Exit", message: "Do you want to exit from community", viewController: self, okButtonTitle: "Exit", cancelButtonTitle: "Cancel", okHandler: {
            for controller in self.navigationController!.viewControllers as Array {
                if controller.isKind(of: InitialViewController.self) {
                    self.navigationController!.popToViewController(controller, animated: true)
                    break
                }
            }
        })
    }
    
}
