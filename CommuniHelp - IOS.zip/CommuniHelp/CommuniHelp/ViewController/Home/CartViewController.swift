//
//  CartViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 11/09/23.
//

import UIKit

class CartViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var segmentControl: UISegmentedControl!
    @IBOutlet weak var cartTableView: UITableView!
    
    var offers: MycommunityOffer!
    var requests: MycommunityRequest!
    var nSelectedSegmentIndex : Int = 1
    
    let userid = UserDefaultsManager.shared.getUserId() ?? ""
    let refid = UserDefaultsManager.shared.getUserRefId() ?? ""
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        self.cartTableView.delegate = self
        self.cartTableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        GetMycommunityOffersAPI()
        GetMycommunityReqAPI()
    }
    
    @IBAction func segmentControlAction(_ sender: Any) {
        if (sender as AnyObject).selectedSegmentIndex == 0 {
                self.nSelectedSegmentIndex = 1
            }
            else {
                self.nSelectedSegmentIndex = 2
            }
            self.cartTableView.reloadData()
    }
    
    @IBAction func backButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func GetMycommunityOffersAPI() {
//        APIHandler().getAPIValues(type: MycommunityOffer.self, apiUrl: ServiceAPI.myCommunityOffers, method: "GET")
        APIHandler().getAPIValues(type: MycommunityOffer.self, apiUrl: "\(ServiceAPI.myCommunityOffers)user_id=\(userid)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.offers = data
                print(self.offers.data ?? "")
                print(self.offers.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.cartTableView.reloadData()
                }
            case.failure(let error):
                print(error)
            }
        }
    }
    
    func GetMycommunityReqAPI() {
//        APIHandler().getAPIValues(type: MycommunityRequest.self, apiUrl: ServiceAPI.myCommunityRequests, method: "GET")
        APIHandler().getAPIValues(type: MycommunityRequest.self, apiUrl: "\(ServiceAPI.myCommunityRequests)user_id=\(userid)", method: "GET") { result in
            switch result {
            case .success(let data):
                self.requests = data
                print(self.requests.data ?? "")
                print(self.requests.data?.count ?? 0)
                DispatchQueue.main.async {
                    self.cartTableView.reloadData()
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
}

extension CartViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if nSelectedSegmentIndex == 1 {
            return self.offers?.data?.count ?? 1
        }
        else {
            return self.requests?.data?.count ?? 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CartTableViewCell", for: indexPath) as! CartTableViewCell
        
        cell.cellView.layer.cornerRadius = 10
        shadow.applyShadowView(to: cell.cellView)
        
        cell.proceedButton.tag = indexPath.row
        cell.proceedButton.addTarget(self, action: #selector(proceedOfferAPI), for: .touchUpInside)
        
        cell.ignoreButton.tag = indexPath.row
        cell.ignoreButton.addTarget(self, action: #selector(ignoreOfferAPI), for: .touchUpInside)
        
        if nSelectedSegmentIndex == 1 {
            if let offer = self.offers?.data?[indexPath.row] {
                cell.infoLabel.text = "\(offer.userID ?? "") : \(offer.category ?? "")\n\(offer.details ?? "")"
            } else {
                cell.infoLabel.text = "No Data"
            }
        } else {
            if let request = self.requests?.data?[indexPath.row] {
                cell.infoLabel.text = "\(request.userID ?? "") : \(request.category ?? "")\n\(request.details ?? "")"
            } else {
                cell.infoLabel.text = "No Data"
            }
        }
        
        cell.proceedButton.titleLabel?.font = .systemFont(ofSize: 12)
        cell.ignoreButton.titleLabel?.font = .systemFont(ofSize: 12)
        
        return cell
    }
    
    @objc func proceedOfferAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        var refID: String? // Initialize refID as an optional String
            
            if self.nSelectedSegmentIndex == 1 {
                // Check if there's an offerRefID at the specified rowToRemove
                if let offerRefID = self.offers?.data?[rowToRemove].refID {
                    refID = offerRefID
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Check if there's a requestRefID at the specified rowToRemove
                if let requestRefID = self.requests?.data?[rowToRemove].refID {
                    refID = requestRefID
                }
            }
            
            guard let validRefID = refID else {
                // Ensure that a valid refID exists for the selected segment
                return
            }
            
            if self.nSelectedSegmentIndex == 1 {
                // Use the selected refID to find the index to remove from "offers" data
                if let indexToRemove = self.offers?.data?.firstIndex(where: { $0.refID == validRefID }) {
                    self.offers?.data?.remove(at: indexToRemove)
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Use the selected refID to find the index to remove from "requests" data
                if let indexToRemove = self.requests?.data?.firstIndex(where: { $0.refID == validRefID }) {
                    self.requests?.data?.remove(at: indexToRemove)
                }
            }
            
            self.cartTableView.reloadData()
            
        let formData: [String: String] = [ "id": validRefID]
        
        APIHandler().postAPIValues(type: proceedModel.self, apiUrl: "\(ServiceAPI.proceedAPI)", method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    self.GetMycommunityOffersAPI()
                    self.GetMycommunityReqAPI()
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
    
    @objc func ignoreOfferAPI(sender: UIButton) {
        let rowToRemove = sender.tag
        var refID: String? // Initialize refID as an optional String
            
            if self.nSelectedSegmentIndex == 1 {
                // Check if there's an offerRefID at the specified rowToRemove
                if let offerRefID = self.offers?.data?[rowToRemove].refID {
                    refID = offerRefID
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Check if there's a requestRefID at the specified rowToRemove
                if let requestRefID = self.requests?.data?[rowToRemove].refID {
                    refID = requestRefID
                }
            }
            
            guard let validRefID = refID else {
                // Ensure that a valid refID exists for the selected segment
                return
            }
            
            if self.nSelectedSegmentIndex == 1 {
                // Use the selected refID to find the index to remove from "offers" data
                if let indexToRemove = self.offers?.data?.firstIndex(where: { $0.refID == validRefID }) {
                    self.offers?.data?.remove(at: indexToRemove)
                }
            } else if self.nSelectedSegmentIndex == 2 {
                // Use the selected refID to find the index to remove from "requests" data
                if let indexToRemove = self.requests?.data?.firstIndex(where: { $0.refID == validRefID }) {
                    self.requests?.data?.remove(at: indexToRemove)
                }
            }
            
            self.cartTableView.reloadData()
            
        let formData: [String: String] = [ "id": validRefID]
        
        APIHandler().postAPIValues(type: ignoreModel.self, apiUrl: "\(ServiceAPI.ignoreAPI)", method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    self.GetMycommunityOffersAPI()
                    self.GetMycommunityReqAPI()
                }
            case .failure(let error):
                print("Error: \(error)")
                // Handle error
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
}
