//
//  HomeViewController.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 09/09/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var helpButton: UIButton!
    @IBOutlet weak var emergencyButton: UIButton!
    @IBOutlet weak var serviceButton: UIButton!
    @IBOutlet weak var cartButton: UIButton!
    @IBOutlet weak var notifyButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.topView.layer.cornerRadius = 35
        self.topView.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        
        shadow.applyShadowButton(to: helpButton)
        shadow.applyShadowButton(to: emergencyButton)
        shadow.applyShadowButton(to: serviceButton)
        shadow.applyShadowButton(to: cartButton)
    }
    
    @IBAction func notifyAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "HomeStoryboard", bundle: nil).instantiateViewController(withIdentifier: "notifyViewController") as! notifyViewController
        navigationController?.pushViewController(storyboard, animated: true)
    }
    
    
    @IBAction func menuButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(identifier: "SettingViewController") as! SettingViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func helpButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "CommunihelpViewController") as! CommunihelpViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func emergencyButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "EmergencyViewController") as! EmergencyViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func serviceButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "HomeServiceViewController") as! HomeServiceViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func cartButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "CartViewController") as! CartViewController
        navigationController?.pushViewController(vc, animated: true)
    }
    
    
}
