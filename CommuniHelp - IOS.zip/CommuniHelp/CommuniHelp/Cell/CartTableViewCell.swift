//
//  CartTableViewCell.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 11/09/23.
//

import UIKit

class CartTableViewCell: UITableViewCell {
    
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var proceedButton: UIButton!
    @IBOutlet weak var ignoreButton: UIButton!
    @IBOutlet weak var cellView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
