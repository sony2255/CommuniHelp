//
//  OfferTableViewCell.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 12/09/23.
//

import UIKit

class OfferTableViewCell: UITableViewCell {

    @IBOutlet weak var radioButton: UIButton!
    @IBOutlet weak var detailsLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
//    func registerUser() {
//                let formData: [String: String] = [
//                    "details": detailsLabel.text ?? "",
//                ]
//                APIHandler().postAPIValues(type: ForgotModel.self, apiUrl: Constants.serviceType.forgotUrl.rawValue, method: "POST", formData: formData) { result in
//                    switch result {
//                    case .success(let response):
//                        print("Status: \(response.status)")
//                        print("Message: \(response.message)")
//                        DispatchQueue.main.async {
//    
//                        }
//                    case .failure(let error):
//                        print("Error: \(error)")
//                    }
//                }
//            }

}
