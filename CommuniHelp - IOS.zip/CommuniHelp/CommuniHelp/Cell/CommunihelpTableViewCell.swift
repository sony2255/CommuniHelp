//
//  CommunihelpTableViewCell.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 11/09/23.
//

import UIKit

class CommunihelpTableViewCell: UITableViewCell {
    
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var acceptButton: UIButton!
    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var reviewButton: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
