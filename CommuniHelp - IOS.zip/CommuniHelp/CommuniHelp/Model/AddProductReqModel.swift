//
//  AddProductReqModel.swift
//  CommuniHelp
//
//  Created by SAIL on 18/10/23.
//

import Foundation

// MARK: - Welcome
struct AddProductReq: Codable {
    var status: Bool?
    var message: String?
}

