// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome = try? JSONDecoder().decode(Welcome.self, from: jsonData)

import Foundation

// MARK: - Welcome
struct MedicalOffer: Codable {
    var status: Bool?
    var message: String?
    var data: [medicalData]?
}

// MARK: - Datum
struct medicalData: Codable {
    var refID, userID, category, details: String?

    enum CodingKeys: String, CodingKey {
        case refID = "ref_id"
        case userID = "user_id"
        case category, details
    }
}
