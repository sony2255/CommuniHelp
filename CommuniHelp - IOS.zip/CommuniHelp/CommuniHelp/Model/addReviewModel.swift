//
//  addReviewModel.swift
//  CommuniHelp
//
//  Created by SAIL on 16/11/23.
//

import Foundation

// MARK: - Welcome
struct addReviewModel: Codable {
    var status: Bool?
    var message: String?
}
