//
//  EmailModel.swift
//  CommuniHelp
//
//  Created by Haris Madhavan on 18/11/23.
//

import Foundation

struct EmailModel: Codable {
    var status: Bool?
    var message: String?
    var data: [Mail]?
}

struct Mail: Codable {
    var email: String?
}
