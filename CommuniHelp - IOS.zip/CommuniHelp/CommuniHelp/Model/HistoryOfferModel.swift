//
//  HistoryModel.swift
//  CommuniHelp
//
//  Created by SAIL on 12/10/23.
//

import Foundation


// MARK: - Welcome
struct HistoryOfferModel: Codable {
    var status: Bool?
    var message: String?
    var data: [HistoryOfferData]?
}

// MARK: - Datum
struct HistoryOfferData: Codable {
    var refID, userID, category, details: String?

    enum CodingKeys: String, CodingKey {
        case refID = "ref_id"
        case userID = "user_id"
        case category, details    }
}


